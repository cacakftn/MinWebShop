﻿using DataAccessLayer.Constat;
using Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class UserRepository : IUserRepository
    {
        public bool Add(User item)
        {
            throw new NotImplementedException();
        }

        public bool Delete(User item)
        {
            throw new NotImplementedException();
        }

        public List<User> GetAll()
        {
            List<User> list = new List<User>();

            using(SqlConnection sqlConnection= new SqlConnection())
            {
                sqlConnection.ConnectionString = ConnectionBase.ConnectionString;
                sqlConnection.Open();

                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandText = "SELECT * FROM Users";

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                while(sqlDataReader.Read())
                {
                    User user = new User();
                    user.IdUser = sqlDataReader.GetInt32(0);
                    user.FrstName = sqlDataReader.GetString(1);
                    user.LastName = sqlDataReader.GetString(2);
                    user.Email = sqlDataReader.GetString(3);
                    user.PasswordHash = sqlDataReader.GetString(4);
                    user.Satus = sqlDataReader.GetBoolean(5);
                    user.CreatedDate = sqlDataReader.GetDateTime(6);
                    user.IdRole = sqlDataReader.GetInt32(7);
                    list.Add(user);

                }

            }
            return list;
        }

        public bool Update(User item)
        {
            throw new NotImplementedException();
        }
    }
}
