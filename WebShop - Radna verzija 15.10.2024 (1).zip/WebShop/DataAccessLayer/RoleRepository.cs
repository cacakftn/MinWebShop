﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class RoleRepository : IRoleRepository
    {
        public bool Add(Role item)
        {
            throw new NotImplementedException();
        }

        public bool Delete(Role item)
        {
            throw new NotImplementedException();
        }

        public List<Role> GetAll()
        {
            throw new NotImplementedException();
        }

        public bool Update(Role item)
        {
            throw new NotImplementedException();
        }
    }
}
